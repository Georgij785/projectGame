extends Sprite2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.
var dir= Vector2()
var speed =10;
var y;
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	if Input.is_action_pressed("ui_left"):
		if y!=2:
			dir.y=0
			dir.x=-1
			y=4
	if Input.is_action_pressed("ui_right"):
		if y!=4:
			dir.y=0
			dir.x=1
			y=2	
	if Input.is_action_pressed("ui_up"):
		if y!=3:
			dir.x=0
			dir.y=-1
			y=1	
	if Input.is_action_pressed("ui_down"):
		if y!=1:
			dir.x=0
			dir.y=1
			y=3		
	var a =2;
	var velocity = dir.normalized()*speed
	position+=velocity

	if Input.is_action_just_pressed("ui_page_up"):
		speed += 1
	if Input.is_action_just_pressed("ui_page_down"):
		if speed >= a:
			speed -= 2
		else: speed=0
	
	
